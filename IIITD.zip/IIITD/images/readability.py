#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct  3 15:12:25 2017

@author: chandresh
"""

import xlwt
import string
import sys
import argparse
from textstat.textstat import textstat

book = xlwt.Workbook()
worksheet = book.add_sheet('ReadabilityScore')
worksheet.write(0, 0, "Tagline")
worksheet.write(0, 1, "flesch_reading_ease")
worksheet.write(0, 2, "flesch_kincaid_grade")
worksheet.write(0, 3, "dale_chall_readability_score")
worksheet.write(0, 4, "gunning_fog")

parser = argparse.ArgumentParser("Calcluate readability scores")                                               

parser.add_argument("--inpfile", "-i", type=str, required=True, help='Name of input file')
parser.add_argument("--outfile","-o", type=str, required=True, help='Name of ouput file')
args = parser.parse_args()

row=1
#for line in iter(f):
#for line in sys.stdin:
with open(args.inpfile,'r') as fid:
    for line in fid:        
            #print("i am in row : ",row)
           # print( "Tagline :", line)
            worksheet.write(row,0,line)
            #print("no of words= ",len(line.split()))
            #line1 = line.lstrip('0123456789.- ,')
           # print( "flesch_reading_ease = ",textstat.flesch_reading_ease(line))
            fre = textstat.flesch_reading_ease(line)
            worksheet.write(row,1,fre)
           # print ("smog_index = ",textstat.smog_index(line))
            smog = textstat.smog_index(line)
           # print( "flesch_kincaid_grade = ",textstat.flesch_kincaid_grade(line))
            fkg = textstat.flesch_kincaid_grade(line)
            worksheet.write(row,2,fkg)
           # print ("dale_chall_readability_score = ", textstat.dale_chall_readability_score(line))
            dcr = textstat.dale_chall_readability_score(line)
            worksheet.write(row,3,dcr)
            #print ("gunning_fog = ",textstat.gunning_fog(line))
            gf = textstat.gunning_fog(line)
            worksheet.write(row,4,gf)
            row+=1

book.save(args.outfile)
