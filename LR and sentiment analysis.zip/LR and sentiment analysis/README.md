The repo contains code for the following models
- logistic regression

Data set used for sentiment classification is moview review data set and can be downloaded from
http://www.cs.cornell.edu/people/pabo/movie-review-data/review_polarity.tar.gz

